package projeto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LogicaReservas {
    private DefaultTableModel modeloTabelaReservas;
    private DefaultListModel<ServicoAdicionalItem> modeloListaServicos;
    private List<PacoteInfo> pacotesInfo;

    public LogicaReservas(DefaultTableModel modeloTabelaReservas, DefaultListModel<ServicoAdicionalItem> modeloListaServicos) {
        this.modeloTabelaReservas = modeloTabelaReservas;
        this.modeloListaServicos = modeloListaServicos;
        this.pacotesInfo = new ArrayList<>();
    }
    
    public void carregarClientes(JComboBox<ComboItem> comboClientes) {
        comboClientes.removeAllItems();
        String sql = "SELECT id, nome FROM clientes ORDER BY nome";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                comboClientes.addItem(new ComboItem(rs.getInt("id"), rs.getString("nome")));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao carregar clientes: " + e.getMessage());
        }
    }

    public void carregarPacotes(JComboBox<ComboItem> comboPacotes) {
        comboPacotes.removeAllItems();
        pacotesInfo.clear();
        String sql = "SELECT id, nome, valor_passagem, valor_diaria, duracao_dias FROM pacotes ORDER BY nome";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                double passagem = rs.getDouble("valor_passagem");
                double diaria = rs.getDouble("valor_diaria");
                int duracao = rs.getInt("duracao_dias");

                comboPacotes.addItem(new ComboItem(id, nome));
                pacotesInfo.add(new PacoteInfo(id, passagem, diaria, duracao));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao carregar pacotes: " + e.getMessage());
        }
    }

    public void carregarServicosAdicionais() {
        modeloListaServicos.clear();
        String sql = "SELECT id, nome, preco FROM servicos_adicionais ORDER BY nome";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                modeloListaServicos.addElement(new ServicoAdicionalItem(rs.getInt("id"), rs.getString("nome"), rs.getDouble("preco")));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao carregar serviços: " + e.getMessage());
        }
    }

    public void carregarTabelaReservas() {
        modeloTabelaReservas.setRowCount(0);
        String sql = """
            SELECT r.id, c.nome AS cliente_nome, p.nome AS pacote_nome, r.quantidade_pessoas, r.valor_final, r.data_reserva
            FROM reservas r
            JOIN clientes c ON r.cliente_id = c.id
            JOIN pacotes p ON r.pacote_id = p.id
            ORDER BY r.data_reserva DESC
            """;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                modeloTabelaReservas.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("cliente_nome"),
                    rs.getString("pacote_nome"),
                    rs.getInt("quantidade_pessoas"),
                    rs.getDouble("valor_final"),
                    rs.getTimestamp("data_reserva").toLocalDateTime().toString()
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao carregar reservas: " + e.getMessage());
        }
    }

    public double calcularValorFinal(JComboBox<ComboItem> comboPacotes, JList<ServicoAdicionalItem> listaServicos, String quantidadePessoasStr) {
        try {
            int qtdPessoas = Integer.parseInt(quantidadePessoasStr);
            if (qtdPessoas <= 0) {
                JOptionPane.showMessageDialog(null, "A quantidade de pessoas deve ser maior que zero.");
                return 0;
            }

            ComboItem itemPacote = (ComboItem) comboPacotes.getSelectedItem();
            if (itemPacote == null) return 0;

            PacoteInfo pacoteSelecionado = pacotesInfo.stream()
                .filter(p -> p.id == itemPacote.getId())
                .findFirst().orElse(null);
            
            if (pacoteSelecionado == null) return 0;

            double custoTotalServicos = 0;
            List<ServicoAdicionalItem> servicosSelecionados = listaServicos.getSelectedValuesList();
            
            for (ServicoAdicionalItem servico : servicosSelecionados) {
                custoTotalServicos += (servico.getPreco() * qtdPessoas);
            }

            double custoBasePacote = (pacoteSelecionado.valorPassagem * qtdPessoas) +
                                     (pacoteSelecionado.valorDiaria * pacoteSelecionado.duracaoDias * qtdPessoas);

            return custoBasePacote + custoTotalServicos;

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor, insira um número válido para a quantidade de pessoas.");
            return 0;
        }
    }

    public boolean confirmarReserva(ComboItem clienteItem, ComboItem pacoteItem, 
                                  String quantidadePessoasStr, JList<ServicoAdicionalItem> listaServicos) {
        try {
            int qtdPessoas = Integer.parseInt(quantidadePessoasStr);
            if (qtdPessoas <= 0) {
                JOptionPane.showMessageDialog(null, "A quantidade de pessoas deve ser maior que zero.");
                return false;
            }

            PacoteInfo pacoteInfo = pacotesInfo.stream()
                .filter(p -> p.id == pacoteItem.getId())
                .findFirst()
                .orElse(null);
            
            if (pacoteInfo == null) {
                JOptionPane.showMessageDialog(null, "Pacote não encontrado.");
                return false;
            }

            List<ServicoAdicionalItem> servicosSelecionados = listaServicos.getSelectedValuesList();
            double valorFinal = calcularValorFinal(new JComboBox<>(new ComboItem[]{pacoteItem}), listaServicos, quantidadePessoasStr);

            Connection conn = null;
            try {
                conn = DatabaseConnection.getConnection();
                conn.setAutoCommit(false);

                String sqlReserva = "INSERT INTO reservas (cliente_id, pacote_id, dias, quantidade_pessoas, valor_final) VALUES (?, ?, ?, ?, ?)";
                int reservaId;
                try (PreparedStatement stmtReserva = conn.prepareStatement(sqlReserva, Statement.RETURN_GENERATED_KEYS)) {
                    stmtReserva.setInt(1, clienteItem.getId());
                    stmtReserva.setInt(2, pacoteItem.getId());
                    stmtReserva.setInt(3, pacoteInfo.duracaoDias);
                    stmtReserva.setInt(4, qtdPessoas);
                    stmtReserva.setDouble(5, valorFinal);
                    stmtReserva.executeUpdate();
                    
                    try (ResultSet generatedKeys = stmtReserva.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            reservaId = generatedKeys.getInt(1);
                        } else {
                            throw new SQLException("Falha ao obter o ID da reserva, nenhuma linha inserida.");
                        }
                    }
                }

                if (!servicosSelecionados.isEmpty()) {
                    String sqlServicos = "INSERT INTO reserva_servicos (reserva_id, servico_id) VALUES (?, ?)";
                    try (PreparedStatement stmtServicos = conn.prepareStatement(sqlServicos)) {
                        for (ServicoAdicionalItem servico : servicosSelecionados) {
                            stmtServicos.setInt(1, reservaId);
                            stmtServicos.setInt(2, servico.getId());
                            stmtServicos.addBatch();
                        }
                        stmtServicos.executeBatch();
                    }
                }

                conn.commit();
                JOptionPane.showMessageDialog(null, "Reserva realizada com sucesso! ID da Reserva: " + reservaId);
                carregarTabelaReservas();
                return true;

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao salvar reserva: " + e.getMessage());
                try {
                    if (conn != null) conn.rollback();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Erro crítico ao reverter a transação: " + ex.getMessage());
                }
                return false;
            } finally {
                try {
                    if (conn != null) conn.setAutoCommit(true);
                } catch (SQLException e) {

                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor, insira um número válido para a quantidade de pessoas.");
            return false;
        }
    }
    

    public static class ComboItem {
        private int id;
        private String texto;
        public ComboItem(int id, String texto) { this.id = id; this.texto = texto; }
        public int getId() { return id; }
        @Override public String toString() { return texto; }
    }

    public static class PacoteInfo {
        int id, duracaoDias;
        double valorPassagem, valorDiaria;
        public PacoteInfo(int id, double vp, double vd, int d) {
            this.id = id; this.valorPassagem = vp; this.valorDiaria = vd; this.duracaoDias = d;
        }
    }

    public static class ServicoAdicionalItem {
        private int id;
        private String nome;
        private double preco;
        public ServicoAdicionalItem(int id, String nome, double preco) {
            this.id = id; this.nome = nome; this.preco = preco;
        }
        public int getId() { return id; }
        public double getPreco() { return preco; }
        @Override public String toString() { return String.format("%s - R$ %.2f", nome, preco); }
    }   
}