package projeto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaPacotes extends JFrame {
    private JTextField txtNome, txtDestino, txtValorPassagem, txtValorDiaria, txtDuracaoDias;
    private JComboBox<String> comboTipo;
    private JButton btnAdicionar, btnLimpar, btnExcluir;
    private JTable tabelaPacotes;
    private DefaultTableModel modeloTabela;
    private JButton btnNewButton;
    private LogicaPacotes logica;
    private JButton btnNewButton_1;

    public TelaPacotes() {
        setTitle("Gerenciamento de Pacotes de Viagem");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout(10, 10));

        JPanel painelFormulario = new JPanel(new GridBagLayout());
        painelFormulario.setBorder(BorderFactory.createTitledBorder("Adicionar Novo Pacote"));

        GridBagConstraints gbcNomeLabel = new GridBagConstraints();
        gbcNomeLabel.gridx = 0;
        gbcNomeLabel.gridy = 0;
        gbcNomeLabel.insets = new Insets(5, 5, 5, 5);
        gbcNomeLabel.anchor = GridBagConstraints.LINE_END;
        painelFormulario.add(new JLabel("Nome:"), gbcNomeLabel); // mostrar onde deve ser inserido o nome do pacote

        GridBagConstraints gbcNomeCampo = new GridBagConstraints();
        gbcNomeCampo.gridx = 1;
        gbcNomeCampo.gridy = 0;
        gbcNomeCampo.gridwidth = 3;
        gbcNomeCampo.insets = new Insets(5, 5, 5, 5);
        gbcNomeCampo.fill = GridBagConstraints.HORIZONTAL;
        txtNome = new JTextField(30);
        painelFormulario.add(txtNome, gbcNomeCampo);

        GridBagConstraints gbcDestinoLabel = new GridBagConstraints();
        gbcDestinoLabel.gridx = 0;
        gbcDestinoLabel.gridy = 1;
        gbcDestinoLabel.insets = new Insets(5, 5, 5, 5);
        gbcDestinoLabel.anchor = GridBagConstraints.LINE_END;
        painelFormulario.add(new JLabel("Destino:"), gbcDestinoLabel); // mostrar onde deve ser inserido o destino do pacote

        GridBagConstraints gbcDestinoCampo = new GridBagConstraints();
        gbcDestinoCampo.gridx = 1;
        gbcDestinoCampo.gridy = 1;
        gbcDestinoCampo.insets = new Insets(5, 5, 5, 5);
        gbcDestinoCampo.fill = GridBagConstraints.HORIZONTAL;
        txtDestino = new JTextField(15);
        painelFormulario.add(txtDestino, gbcDestinoCampo);

        GridBagConstraints gbcTipoLabel = new GridBagConstraints();
        gbcTipoLabel.gridx = 2;
        gbcTipoLabel.gridy = 1;
        gbcTipoLabel.insets = new Insets(5, 5, 5, 5);
        gbcTipoLabel.anchor = GridBagConstraints.LINE_END;
        painelFormulario.add(new JLabel("Tipo:"), gbcTipoLabel); // lugar onde vai escolher qual é o tipo do pacote

        GridBagConstraints gbcTipoCampo = new GridBagConstraints();
        gbcTipoCampo.gridx = 3;
        gbcTipoCampo.gridy = 1;
        gbcTipoCampo.insets = new Insets(5, 5, 5, 5);
        gbcTipoCampo.fill = GridBagConstraints.HORIZONTAL;
        comboTipo = new JComboBox<>(new String[]{"LUXO", "CULTURAL", "AVENTURA", "PADRAO"}); // tipos de pacotes!
        painelFormulario.add(comboTipo, gbcTipoCampo);

        GridBagConstraints gbcValorPassagemLabel = new GridBagConstraints();
        gbcValorPassagemLabel.gridx = 0;
        gbcValorPassagemLabel.gridy = 2;
        gbcValorPassagemLabel.insets = new Insets(5, 5, 5, 5);
        gbcValorPassagemLabel.anchor = GridBagConstraints.LINE_END;
        painelFormulario.add(new JLabel("Valor Passagem:"), gbcValorPassagemLabel); // indica onde deve ser inserido o valor da passagem

        GridBagConstraints gbcValorPassagemCampo = new GridBagConstraints();
        gbcValorPassagemCampo.gridx = 1;
        gbcValorPassagemCampo.gridy = 2;
        gbcValorPassagemCampo.insets = new Insets(5, 5, 5, 5);
        gbcValorPassagemCampo.fill = GridBagConstraints.HORIZONTAL;
        txtValorPassagem = new JTextField(10);
        painelFormulario.add(txtValorPassagem, gbcValorPassagemCampo);

        GridBagConstraints gbcValorDiariaLabel = new GridBagConstraints();
        gbcValorDiariaLabel.gridx = 2;
        gbcValorDiariaLabel.gridy = 2;
        gbcValorDiariaLabel.insets = new Insets(5, 5, 5, 5);
        gbcValorDiariaLabel.anchor = GridBagConstraints.LINE_END;
        painelFormulario.add(new JLabel("Valor Diária:"), gbcValorDiariaLabel); // indica o lugar q deve ser inserido o valor da diária

        GridBagConstraints gbcValorDiariaCampo = new GridBagConstraints();
        gbcValorDiariaCampo.gridx = 3;
        gbcValorDiariaCampo.gridy = 2;
        gbcValorDiariaCampo.insets = new Insets(5, 5, 5, 5);
        gbcValorDiariaCampo.fill = GridBagConstraints.HORIZONTAL;
        txtValorDiaria = new JTextField(10);
        painelFormulario.add(txtValorDiaria, gbcValorDiariaCampo);

        GridBagConstraints gbcDuracaoLabel = new GridBagConstraints();
        gbcDuracaoLabel.gridx = 0;
        gbcDuracaoLabel.gridy = 3;
        gbcDuracaoLabel.insets = new Insets(5, 5, 5, 5);
        gbcDuracaoLabel.anchor = GridBagConstraints.LINE_END;
        painelFormulario.add(new JLabel("Duração (dias):"), gbcDuracaoLabel); // indica onde deve ser inserido a duração em dias

        GridBagConstraints gbcDuracaoCampo = new GridBagConstraints();
        gbcDuracaoCampo.gridx = 1;
        gbcDuracaoCampo.gridy = 3;
        gbcDuracaoCampo.insets = new Insets(5, 5, 5, 5);
        gbcDuracaoCampo.fill = GridBagConstraints.HORIZONTAL;
        txtDuracaoDias = new JTextField(5);
        painelFormulario.add(txtDuracaoDias, gbcDuracaoCampo);

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnAdicionar = new JButton("Adicionar Pacote"); //botão p adicionar o pacote
        btnLimpar = new JButton("Limpar Campos"); //botao p limpar campos 
        painelBotoes.add(btnAdicionar);
        painelBotoes.add(btnLimpar);

        GridBagConstraints gbcBotoes = new GridBagConstraints();
        gbcBotoes.gridx = 0;
        gbcBotoes.gridy = 4;
        gbcBotoes.gridwidth = 4;
        gbcBotoes.insets = new Insets(10, 5, 0, 5);
        painelFormulario.add(painelBotoes, gbcBotoes);

        modeloTabela = new DefaultTableModel(new Object[]{"ID", "Nome", "Destino", "Tipo", "Passagem", "Diária", "Duração"}, 0); // modelo a ser carregado as info dos pacotes
        tabelaPacotes = new JTable(modeloTabela);
        JScrollPane scrollTabela = new JScrollPane(tabelaPacotes);
        scrollTabela.setBorder(BorderFactory.createTitledBorder("Pacotes Disponíveis"));

        JPanel painelExcluir = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnExcluir = new JButton("Excluir Pacote Selecionado");
        painelExcluir.add(btnExcluir);

        getContentPane().add(painelFormulario, BorderLayout.NORTH);
        
        btnNewButton_1 = new JButton("Buscar Pacote"); // botao pra buscar pacote
        btnNewButton_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		LogicaPacotes.buscarPacote();
        	}
        });
        GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
        gbc_btnNewButton_1.gridx = 4;
        gbc_btnNewButton_1.gridy = 4;
        painelFormulario.add(btnNewButton_1, gbc_btnNewButton_1);
        getContentPane().add(scrollTabela, BorderLayout.CENTER);
        getContentPane().add(painelExcluir, BorderLayout.SOUTH);
        
        btnNewButton = new JButton("Voltar ao Menu Principal"); // botão p voltar ao menu principal
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                TelaPrincipal TelaPrincipal = new TelaPrincipal();
                TelaPrincipal.setVisible(true);
                TelaPacotes.this.dispose();
            }
        });
        painelExcluir.add(btnNewButton);

        logica = new LogicaPacotes(modeloTabela);
        // chamando os metodos pros botões
        btnAdicionar.addActionListener(e -> adicionarPacote());
        btnLimpar.addActionListener(e -> limparCampos());
        btnExcluir.addActionListener(e -> excluirPacote());

        logica.carregarTabelaPacotes();
    }

    private void adicionarPacote() { // método de adc pacote
        String nome = txtNome.getText();
        String destino = txtDestino.getText();
        String tipo = (String) comboTipo.getSelectedItem();
        String valorPassagem = txtValorPassagem.getText();
        String valorDiaria = txtValorDiaria.getText();
        String duracaoDias = txtDuracaoDias.getText();

        if (logica.adicionarPacote(nome, destino, tipo, valorPassagem, valorDiaria, duracaoDias)) {
            limparCampos();
        }
    }

    private void excluirPacote() { // chama o método de excluir pacote
        int linhaSelecionada = tabelaPacotes.getSelectedRow();
        logica.excluirPacote(linhaSelecionada);
    }

    private void limparCampos() { // método de limpar os campos dos pacotes
        txtNome.setText("");
        txtDestino.setText("");
        comboTipo.setSelectedIndex(0);
        txtValorPassagem.setText("");
        txtValorDiaria.setText("");
        txtDuracaoDias.setText("");
        tabelaPacotes.clearSelection();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TelaPacotes tela = new TelaPacotes();
            tela.setVisible(true);
        });
    }
}