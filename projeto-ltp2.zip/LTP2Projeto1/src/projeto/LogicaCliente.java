package projeto;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class LogicaCliente {
    public static void cadastrarCliente(JFrame parentFrame, JTextField txtNome, JTextField txtEmail,
                                       JTextField txtTelefone, JTextField txtCpf, JTextField txtPassaporte,
                                       JRadioButton rbNacional, DefaultTableModel modeloTabela) {
        if (txtNome.getText().trim().isEmpty() || txtEmail.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(parentFrame, 
                "Nome e Email são obrigatórios.", 
                "Erro de Validação", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        String sql = "INSERT INTO clientes (tipo, nome, telefone, email, cpf, passaporte) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            String tipoStr = rbNacional.isSelected() ? "NACIONAL" : "ESTRANGEIRO";
            stmt.setString(1, tipoStr);
            stmt.setString(2, txtNome.getText().trim());
            stmt.setString(3, txtTelefone.getText().trim());
            stmt.setString(4, txtEmail.getText().trim());

            if (rbNacional.isSelected()) {
                stmt.setString(5, txtCpf.getText().trim());
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setNull(5, java.sql.Types.VARCHAR);
                stmt.setString(6, txtPassaporte.getText().trim());
            }

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(parentFrame, 
                "Cliente cadastrado com sucesso!", 
                "Sucesso", 
                JOptionPane.INFORMATION_MESSAGE);

            limparCampos(txtNome, txtEmail, txtTelefone, txtCpf, txtPassaporte, rbNacional);
            carregarTabelaClientes(modeloTabela);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(parentFrame, 
                "Erro ao cadastrar cliente: " + e.getMessage(), 
                "Erro de Banco de Dados", 
                JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void limparCampos(JTextField txtNome, JTextField txtEmail, JTextField txtTelefone,
                                   JTextField txtCpf, JTextField txtPassaporte, JRadioButton rbNacional) {
        txtNome.setText("");
        txtEmail.setText("");
        txtTelefone.setText("");
        txtCpf.setText("");
        txtPassaporte.setText("");
        rbNacional.setSelected(true);
    }
    public static void buscarCliente() {
        String nomeBusca = JOptionPane.showInputDialog("Nome do cliente:");
        if (nomeBusca == null || nomeBusca.trim().isEmpty()) return;

        StringBuilder res = new StringBuilder();

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM clientes WHERE LOWER(nome) LIKE ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, "%" + nomeBusca.toLowerCase() + "%");
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        res.append("Nome: ").append(rs.getString("nome"))
                           .append("\nEmail: ").append(rs.getString("email"))
                           .append("\nTelefone: ").append(rs.getString("telefone"));

                        String tipo = rs.getString("tipo");
                        if (tipo.equals("NACIONAL")) {
                            res.append("\nCPF: ").append(rs.getString("cpf"));
                        } else if (tipo.equals("ESTRANGEIRO")) {
                            res.append("\nPassaporte: ").append(rs.getString("passaporte"));
                        }

                        res.append("\n\n");
                    }
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar cliente: " + e.getMessage());
            return;
        }

        JOptionPane.showMessageDialog(null, res.length() > 0 ? res.toString() : "Cliente não encontrado.");
    }
    
    public static void visualizarPacotesCliente() {
        String nomeCliente = JOptionPane.showInputDialog("Digite o nome do cliente:");
        if (nomeCliente == null || nomeCliente.trim().isEmpty()) return;

        StringBuilder pacotesCliente = new StringBuilder();

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sqlCliente = "SELECT id, nome FROM clientes WHERE LOWER(nome) LIKE ?";
            int clienteId = -1;
            String nomeCompleto = null;

            try (PreparedStatement stmt = conn.prepareStatement(sqlCliente)) {
                stmt.setString(1, nomeCliente.toLowerCase() + "%");
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        clienteId = rs.getInt("id");
                        nomeCompleto = rs.getString("nome");
                    } else {
                        JOptionPane.showMessageDialog(null, "Cliente não encontrado.");
                        return;
                    }
                }
            }
            String sqlReservas = """
                SELECT p.nome AS pacote_nome, r.valor_final
                FROM reservas r
                JOIN pacotes p ON r.pacote_id = p.id
                WHERE r.cliente_id = ?
            """;

            try (PreparedStatement stmt = conn.prepareStatement(sqlReservas)) {
                stmt.setInt(1, clienteId);
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        pacotesCliente.append("Cliente: ").append(nomeCompleto).append("\n")
                                .append("Pacote: ").append(rs.getString("pacote_nome"))
                                .append("\nValor: R$").append(rs.getDouble("valor_final"))
                                .append("\n\n");
                    }
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar pacotes do cliente: " + e.getMessage());
            return;
        }

        if (pacotesCliente.length() == 0) {
            JOptionPane.showMessageDialog(null, "Este cliente não possui pacotes contratados.");
        } else {
            JOptionPane.showMessageDialog(null, pacotesCliente.toString());
        }
    }

    public static void carregarTabelaClientes(DefaultTableModel modeloTabela) {
        modeloTabela.setRowCount(0);
        String sql = "SELECT id, nome, email, telefone, tipo, cpf, passaporte FROM clientes ORDER BY nome";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String tipo = rs.getString("tipo");
                String documento = "NACIONAL".equalsIgnoreCase(tipo) ? rs.getString("cpf") : rs.getString("passaporte");
                
                modeloTabela.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("email"),
                    rs.getString("telefone"),
                    tipo,
                    documento
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao carregar clientes: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void excluirCliente(JFrame parentFrame, JTable tabelaClientes, DefaultTableModel modeloTabela) {
        int linhaSelecionada = tabelaClientes.getSelectedRow();
        if (linhaSelecionada == -1) {
            JOptionPane.showMessageDialog(parentFrame, 
                "Selecione um cliente na tabela para excluir.", 
                "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int idCliente = (int) modeloTabela.getValueAt(linhaSelecionada, 0);
        String nomeCliente = (String) modeloTabela.getValueAt(linhaSelecionada, 1);
        
        int confirmacao = JOptionPane.showConfirmDialog(parentFrame, 
            "Tem certeza que deseja excluir o cliente: " + nomeCliente + "?", 
            "Confirmação", JOptionPane.YES_NO_OPTION);
        
        if (confirmacao != JOptionPane.YES_OPTION) return;

        try (Connection conn = DatabaseConnection.getConnection()) {

            String verificarReservas = "SELECT COUNT(*) FROM reservas WHERE cliente_id = ?";
            try (PreparedStatement stmtCheck = conn.prepareStatement(verificarReservas)) {
                stmtCheck.setInt(1, idCliente);
                ResultSet rs = stmtCheck.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(parentFrame, 
                        "Este cliente possui reservas e não pode ser excluído.", 
                        "Operação Bloqueada", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            String excluirCliente = "DELETE FROM clientes WHERE id = ?";
            try (PreparedStatement stmtDelete = conn.prepareStatement(excluirCliente)) {
                stmtDelete.setInt(1, idCliente);
                stmtDelete.executeUpdate();
                JOptionPane.showMessageDialog(parentFrame, 
                    "Cliente excluído com sucesso!", 
                    "Sucesso", JOptionPane.INFORMATION_MESSAGE);
   
                modeloTabela.removeRow(linhaSelecionada);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(parentFrame, 
                "Erro ao excluir cliente: " + e.getMessage(), 
                "Erro de Banco de Dados", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public static void validarDadosCliente(String nome, String documento, String telefone, String email, String tipoCliente) throws IllegalArgumentException {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("O campo 'Nome' é obrigatório.");
        }

        if (documento == null || documento.trim().isEmpty()) {
            throw new IllegalArgumentException("O campo 'CPF/Passaporte' é obrigatório.");
        }

        if (telefone == null || telefone.trim().isEmpty()) {
            throw new IllegalArgumentException("O campo 'Telefone' é obrigatório.");
        }

        if (tipoCliente.equalsIgnoreCase("Nacional")) {
            if (!documento.matches("\\d{11}")) {
                throw new IllegalArgumentException("CPF inválido. Deve conter 11 dígitos numéricos.");
            }
        } else if (tipoCliente.equalsIgnoreCase("Estrangeiro")) {
            if (!documento.matches("[A-Za-z0-9]{6,}")) {
                throw new IllegalArgumentException("Passaporte inválido. Deve conter ao menos 6 caracteres alfanuméricos.");
            }
        }

        if (email != null && !email.trim().isEmpty()) {
            if (!email.matches("^[\\w\\.-]+@[\\w\\.-]+\\.\\w+$")) {
                throw new IllegalArgumentException("E-mail em formato inválido.");
            }
        }
    }

}