package projeto;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class TelaLogin extends JFrame {

    private JPasswordField passwordField;
    private JTextField textFieldUsuario;
    
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                TelaLogin frame = new TelaLogin();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public TelaLogin() {
    	setTitle("Login - Agência de Viagens");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        getContentPane().add(panel);

        Insets defaultInsets = new Insets(10, 10, 10, 10);

        GridBagConstraints gbcTitulo = new GridBagConstraints();
        gbcTitulo.gridx = 0;
        gbcTitulo.gridy = 0;
        gbcTitulo.gridwidth = 2;
        gbcTitulo.fill = GridBagConstraints.HORIZONTAL;
        gbcTitulo.anchor = GridBagConstraints.CENTER;
        gbcTitulo.insets = defaultInsets;
        JLabel lblTitulo = new JLabel("Bem-vindo ao Sistema");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(lblTitulo, gbcTitulo);

        GridBagConstraints gbcLblUsuario = new GridBagConstraints();
        gbcLblUsuario.gridx = 0;
        gbcLblUsuario.gridy = 2;
        gbcLblUsuario.gridwidth = 1;
        gbcLblUsuario.anchor = GridBagConstraints.LINE_END;
        gbcLblUsuario.insets = defaultInsets;
        JLabel lblUsuario = new JLabel("Usuário:"); //jlabel pra inserir o usuário que está entrando no sistema
        lblUsuario.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(lblUsuario, gbcLblUsuario);

        GridBagConstraints gbcTxtUsuario = new GridBagConstraints();
        gbcTxtUsuario.gridx = 1;
        gbcTxtUsuario.gridy = 2;
        gbcTxtUsuario.anchor = GridBagConstraints.LINE_START;
        gbcTxtUsuario.insets = defaultInsets;
        textFieldUsuario = new JTextField(15);
        textFieldUsuario.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(textFieldUsuario, gbcTxtUsuario);

        GridBagConstraints gbcLblSenha = new GridBagConstraints();
        gbcLblSenha.gridx = 0;
        gbcLblSenha.gridy = 3;
        gbcLblSenha.anchor = GridBagConstraints.LINE_END;
        gbcLblSenha.insets = defaultInsets;
        JLabel lblSenha = new JLabel("Senha:"); //jlabel pra inserir a senha 
        lblSenha.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(lblSenha, gbcLblSenha);

        GridBagConstraints gbcSenha = new GridBagConstraints();
        gbcSenha.gridx = 1;
        gbcSenha.gridy = 3;
        gbcSenha.anchor = GridBagConstraints.LINE_START;
        gbcSenha.insets = defaultInsets;
        passwordField = new JPasswordField(15);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(passwordField, gbcSenha);

        GridBagConstraints gbcBtnEntrar = new GridBagConstraints(); // botão d entrar
        gbcBtnEntrar.gridx = 0;
        gbcBtnEntrar.gridy = 4;
        gbcBtnEntrar.gridwidth = 2;
        gbcBtnEntrar.anchor = GridBagConstraints.CENTER;
        gbcBtnEntrar.insets = defaultInsets;
        JButton btnEntrar = new JButton("Entrar");
        btnEntrar.setFont(new Font("Arial", Font.BOLD, 14));
        btnEntrar.setBackground(new Color(70, 130, 180));
        btnEntrar.setForeground(Color.WHITE);
        btnEntrar.setFocusPainted(false);
        btnEntrar.setPreferredSize(new Dimension(120, 35));
        panel.add(btnEntrar, gbcBtnEntrar);

        btnEntrar.addActionListener(e -> { // ação p botão de entrar para conferir se usuário e senha estão certos
            String usuario = textFieldUsuario.getText();
            String senha = new String(passwordField.getPassword());

            if (usuario.equals("admin") && senha.equals("1234")) { 
                TelaPrincipal menu = new TelaPrincipal();
                menu.setVisible(true);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Usuário ou senha incorretos!",
                        "Erro de login",
                        JOptionPane.ERROR_MESSAGE);
                textFieldUsuario.setText("");
                passwordField.setText("");
            }
        });
        getRootPane().setDefaultButton(btnEntrar);
    }
}