package projeto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaReservas extends JFrame {

    private JComboBox<LogicaReservas.ComboItem> comboClientes, comboPacotes;
    private JTextField txtQuantidadePessoas;
    private JList<LogicaReservas.ServicoAdicionalItem> listaServicos;
    private DefaultListModel<LogicaReservas.ServicoAdicionalItem> modeloListaServicos;
    private JLabel lblValorTotal;
    private JButton btnCalcular, btnConfirmar, btnLimpar;
    private JTable tabelaReservas;
    private DefaultTableModel modeloTabelaReservas;
    private LogicaReservas logicaReservas;
    private JButton btnNewButton;

    public TelaReservas() {
        setTitle("Gerenciamento de Reservas");
        setSize(900, 700);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout(10, 10));

        modeloTabelaReservas = new DefaultTableModel(
            new Object[]{"ID", "Cliente", "Pacote", "Pessoas", "Valor Final", "Data"}, 0);
        modeloListaServicos = new DefaultListModel<>();
        logicaReservas = new LogicaReservas(modeloTabelaReservas, modeloListaServicos);

        JPanel painelFormulario = new JPanel(new GridBagLayout());
        painelFormulario.setBorder(BorderFactory.createTitledBorder("Nova Reserva"));

        GridBagConstraints gbcLabelCliente = new GridBagConstraints();
        gbcLabelCliente.gridx = 0;
        gbcLabelCliente.gridy = 0;
        gbcLabelCliente.insets = new Insets(5, 5, 5, 5);
        gbcLabelCliente.fill = GridBagConstraints.HORIZONTAL;
        painelFormulario.add(new JLabel("Cliente:"), gbcLabelCliente); // qual cliente?

        GridBagConstraints gbcComboCliente = new GridBagConstraints();
        gbcComboCliente.gridx = 1;
        gbcComboCliente.gridy = 0;
        gbcComboCliente.insets = new Insets(5, 5, 5, 0);
        gbcComboCliente.fill = GridBagConstraints.HORIZONTAL;
        comboClientes = new JComboBox<>();
        painelFormulario.add(comboClientes, gbcComboCliente);

        GridBagConstraints gbcLabelPacote = new GridBagConstraints();
        gbcLabelPacote.gridx = 0;
        gbcLabelPacote.gridy = 2;
        gbcLabelPacote.insets = new Insets(5, 5, 5, 5);
        gbcLabelPacote.fill = GridBagConstraints.HORIZONTAL;
        painelFormulario.add(new JLabel("Pacote:"), gbcLabelPacote); // qual pacote?

        GridBagConstraints gbcComboPacote = new GridBagConstraints();
        gbcComboPacote.gridx = 1;
        gbcComboPacote.gridy = 2;
        gbcComboPacote.insets = new Insets(5, 5, 5, 0);
        gbcComboPacote.fill = GridBagConstraints.HORIZONTAL;
        comboPacotes = new JComboBox<>();
        painelFormulario.add(comboPacotes, gbcComboPacote);

        GridBagConstraints gbcLabelPessoas = new GridBagConstraints();
        gbcLabelPessoas.gridx = 0;
        gbcLabelPessoas.gridy = 3;
        gbcLabelPessoas.insets = new Insets(5, 5, 5, 5);
        gbcLabelPessoas.fill = GridBagConstraints.HORIZONTAL;
        painelFormulario.add(new JLabel("Nº de Pessoas:"), gbcLabelPessoas); // indica local pra escrever o número de pessoas

        GridBagConstraints gbcTxtPessoas = new GridBagConstraints();
        gbcTxtPessoas.gridx = 1;
        gbcTxtPessoas.gridy = 3;
        gbcTxtPessoas.insets = new Insets(5, 5, 5, 0);
        gbcTxtPessoas.fill = GridBagConstraints.HORIZONTAL;
        txtQuantidadePessoas = new JTextField(5);
        painelFormulario.add(txtQuantidadePessoas, gbcTxtPessoas);

        GridBagConstraints gbcLabelServicos = new GridBagConstraints();
        gbcLabelServicos.gridx = 0;
        gbcLabelServicos.gridy = 4;
        gbcLabelServicos.insets = new Insets(5, 5, 5, 5);
        gbcLabelServicos.anchor = GridBagConstraints.NORTH;
        painelFormulario.add(new JLabel("Serviços adicionais:"), gbcLabelServicos); //quais serviços adicionais deseja?

        GridBagConstraints gbcListaServicos = new GridBagConstraints();
        gbcListaServicos.gridx = 1;
        gbcListaServicos.gridy = 4;
        gbcListaServicos.insets = new Insets(5, 5, 5, 0);
        gbcListaServicos.fill = GridBagConstraints.BOTH;
        gbcListaServicos.weighty = 1.0;
        listaServicos = new JList<>(modeloListaServicos);
        listaServicos.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        JScrollPane scrollServicos = new JScrollPane(listaServicos);
        scrollServicos.setPreferredSize(new Dimension(250, 100));
        painelFormulario.add(scrollServicos, gbcListaServicos);
        
        JLabel lblObservacao = new JLabel("Obs: Segure Ctrl ou Shift para selecionar vários.");
        lblObservacao.setFont(new Font("Arial", Font.ITALIC, 11));
        lblObservacao.setForeground(Color.GRAY);

        GridBagConstraints gbcObservacao = new GridBagConstraints();
        gbcObservacao.gridx = 1;
        gbcObservacao.gridy = 5;
        gbcObservacao.anchor = GridBagConstraints.NORTHWEST;
        gbcObservacao.insets = new Insets(2, 5, 5, 0);
        painelFormulario.add(lblObservacao, gbcObservacao);

        GridBagConstraints gbcAcoes = new GridBagConstraints();
        gbcAcoes.gridx = 0;
        gbcAcoes.gridy = 6;
        gbcAcoes.gridwidth = 2;
        gbcAcoes.insets = new Insets(10, 0, 5, 0);
        gbcAcoes.anchor = GridBagConstraints.CENTER;

        JPanel painelAcoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        // criação de botões e jlabel do valor ttl
        btnCalcular = new JButton("Calcular Valor Final");
        lblValorTotal = new JLabel("Valor Total: R$ 0.00");
        lblValorTotal.setFont(new Font("Arial", Font.BOLD, 14));
        btnConfirmar = new JButton("Confirmar Reserva");
        btnLimpar = new JButton("Limpar");

        painelAcoes.add(btnCalcular);
        painelAcoes.add(lblValorTotal);
        painelAcoes.add(btnConfirmar);
        painelAcoes.add(btnLimpar);

        painelFormulario.add(painelAcoes, gbcAcoes);

        tabelaReservas = new JTable(modeloTabelaReservas);
        JScrollPane scrollTabela = new JScrollPane(tabelaReservas);
        scrollTabela.setBorder(BorderFactory.createTitledBorder("Reservas Realizadas"));

        getContentPane().add(painelFormulario, BorderLayout.NORTH);
        getContentPane().add(scrollTabela, BorderLayout.CENTER);
        JPanel painelAcoesTabela = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        getContentPane().add(painelAcoesTabela, BorderLayout.SOUTH);
        
        btnNewButton = new JButton("Voltar ao Menu Principal");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                TelaPrincipal TelaPrincipal = new TelaPrincipal();
                TelaPrincipal.setVisible(true);
                TelaReservas.this.dispose();
            }
        });
        painelAcoesTabela.add(btnNewButton);

        carregarDados();
        //chama os métodos pros botões
        btnCalcular.addActionListener(e -> calcularValorFinal());
        btnConfirmar.addActionListener(e -> confirmarReserva());
        btnLimpar.addActionListener(e -> limparCampos());
    }

    private void carregarDados() {
    	//chama os métodos de logicaReservas
        logicaReservas.carregarClientes(comboClientes);
        logicaReservas.carregarPacotes(comboPacotes);
        logicaReservas.carregarServicosAdicionais();
        logicaReservas.carregarTabelaReservas();
    }

    private void calcularValorFinal() {
    	//chama o método de logicaReservas
        double valorFinal = logicaReservas.calcularValorFinal(
            comboPacotes, 
            listaServicos, 
            txtQuantidadePessoas.getText()
        );
        lblValorTotal.setText(String.format("Valor Total: R$ %.2f", valorFinal));
    }

    private void confirmarReserva() {
    	//chama o método de logicaReservas
        LogicaReservas.ComboItem clienteItem = (LogicaReservas.ComboItem) comboClientes.getSelectedItem();
        LogicaReservas.ComboItem pacoteItem = (LogicaReservas.ComboItem) comboPacotes.getSelectedItem();
        
        boolean sucesso = logicaReservas.confirmarReserva(
            clienteItem,
            pacoteItem,
            txtQuantidadePessoas.getText(),
            listaServicos
        );
        
        if (sucesso) {
            limparCampos();
        }
    }

    private void limparCampos() { // metodo p limpar campos
        comboClientes.setSelectedIndex(0);
        comboPacotes.setSelectedIndex(0);
        txtQuantidadePessoas.setText("");
        listaServicos.clearSelection();
        lblValorTotal.setText("Valor Total: R$ 0.00");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TelaReservas tela = new TelaReservas();
            tela.setVisible(true);
        });
    }
}