package projeto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LogicaPacotes {
    private DefaultTableModel modeloTabela;

    public LogicaPacotes(DefaultTableModel modeloTabela) {
        this.modeloTabela = modeloTabela;
    }

    public void carregarTabelaPacotes() {
        modeloTabela.setRowCount(0);
        String sql = "SELECT id, nome, destino, tipo, valor_passagem, valor_diaria, duracao_dias FROM pacotes";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                modeloTabela.addRow(new Object[]{
                    rs.getInt("id"), rs.getString("nome"), rs.getString("destino"),
                    rs.getString("tipo"), rs.getDouble("valor_passagem"),
                    rs.getDouble("valor_diaria"), rs.getInt("duracao_dias")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao carregar pacotes: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean adicionarPacote(String nome, String destino, String tipo, 
                                  String valorPassagemStr, String valorDiariaStr, 
                                  String duracaoDiasStr) {
        try {
            if (nome.trim().isEmpty() || destino.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Nome e Destino são obrigatórios.", "Erro", JOptionPane.WARNING_MESSAGE);
                return false;
            }

            double valorPassagem = Double.parseDouble(valorPassagemStr);
            double valorDiaria = Double.parseDouble(valorDiariaStr);
            int duracaoDias = Integer.parseInt(duracaoDiasStr);

            String sql = "INSERT INTO pacotes (nome, destino, tipo, valor_passagem, valor_diaria, duracao_dias) VALUES (?, ?, ?, ?, ?, ?)";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, nome);
                stmt.setString(2, destino);
                stmt.setString(3, tipo);
                stmt.setDouble(4, valorPassagem);
                stmt.setDouble(5, valorDiaria);
                stmt.setInt(6, duracaoDias);
                stmt.executeUpdate();
                
                JOptionPane.showMessageDialog(null, "Pacote adicionado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                carregarTabelaPacotes();
                return true;
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao salvar pacote: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Valores de passagem, diária e duração devem ser números válidos.", "Erro de Formato", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public boolean excluirPacote(int linhaSelecionada) {
        if (linhaSelecionada == -1) {
            JOptionPane.showMessageDialog(null, "Selecione um pacote na tabela para excluir.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        int idPacote = (int) modeloTabela.getValueAt(linhaSelecionada, 0);
        int confirmacao = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja excluir este pacote?", "Confirmação", JOptionPane.YES_NO_OPTION);
        if (confirmacao != JOptionPane.YES_OPTION) return false;

        try (Connection conn = DatabaseConnection.getConnection()) {

            String sqlCheck = "SELECT COUNT(*) FROM reservas WHERE pacote_id = ?";
            try (PreparedStatement stmtCheck = conn.prepareStatement(sqlCheck)) {
                stmtCheck.setInt(1, idPacote);
                ResultSet rs = stmtCheck.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(null, "Este pacote está vinculado a uma reserva e não pode ser excluído.", "Erro", JOptionPane.ERROR_MESSAGE);
                    return false;
                }
            }

            String sqlDelete = "DELETE FROM pacotes WHERE id = ?";
            try (PreparedStatement stmtDelete = conn.prepareStatement(sqlDelete)) {
                stmtDelete.setInt(1, idPacote);
                stmtDelete.executeUpdate();
                JOptionPane.showMessageDialog(null, "Pacote excluído com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                carregarTabelaPacotes();
                return true;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir pacote: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    public static void buscarPacote() {
        String nomePacote = JOptionPane.showInputDialog("Digite o nome do pacote:");
        if (nomePacote == null || nomePacote.trim().isEmpty()) return;

        StringBuilder res = new StringBuilder();

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sqlPacote = "SELECT id, nome, destino, tipo, valor_passagem, valor_diaria, duracao_dias FROM pacotes WHERE LOWER(nome) LIKE ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlPacote)) {
                stmt.setString(1, nomePacote.toLowerCase() + "%"); // 👈 começa com

                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        int id = rs.getInt("id");

                        res.append("Pacote: ").append(rs.getString("nome"))
                           .append(" - ").append(rs.getString("destino"))
                           .append("\nTipo: ").append(rs.getString("tipo"))
                           .append("\nPassagem: R$").append(rs.getDouble("valor_passagem"))
                           .append(" | Diária: R$").append(rs.getDouble("valor_diaria"))
                           .append(" | Duração: ").append(rs.getInt("duracao_dias")).append(" dias\n");

                        String sqlClientes = "SELECT c.nome FROM reservas r " +
                                             "JOIN clientes c ON r.cliente_id = c.id " +
                                             "WHERE r.pacote_id = ?";
                        try (PreparedStatement stmtClientes = conn.prepareStatement(sqlClientes)) {
                            stmtClientes.setInt(1, id);
                            try (ResultSet rsClientes = stmtClientes.executeQuery()) {
                                boolean temClientes = false;
                                res.append("Clientes que contrataram este pacote:\n");
                                while (rsClientes.next()) {
                                    res.append("- ").append(rsClientes.getString("nome")).append("\n");
                                    temClientes = true;
                                }
                                if (!temClientes) {
                                    res.append("Nenhum cliente contratou este pacote.\n");
                                }
                            }
                        }

                        res.append("\n");
                    }
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar pacote: " + e.getMessage());
            return;
        }

        JOptionPane.showMessageDialog(null, res.length() > 0 ? res.toString() : "Pacote não encontrado.");
    }
}