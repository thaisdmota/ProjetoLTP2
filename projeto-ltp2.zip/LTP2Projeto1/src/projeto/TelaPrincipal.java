package projeto;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class TelaPrincipal extends JFrame {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TelaPrincipal frame = new TelaPrincipal();
            frame.setVisible(true);
        });
    }

    public TelaPrincipal() {
        setTitle("Sistema de Viagens");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 450);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel contentPane = new JPanel(new BorderLayout());
        contentPane.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        setContentPane(contentPane);

        JLabel lblTitulo = new JLabel("Menu Principal", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
        contentPane.add(lblTitulo, BorderLayout.NORTH);

        JPanel panelBotoes = new JPanel();
        panelBotoes.setLayout(new BoxLayout(panelBotoes, BoxLayout.Y_AXIS));
        panelBotoes.setBorder(BorderFactory.createEmptyBorder(20, 100, 20, 100));

        String[] opcoes = {"Clientes", "Pacotes", "Serviços", "Reservas", "Sair"};
        for (String opcao : opcoes) {
            JButton btn = criarBotao(opcao);
            panelBotoes.add(btn);
            panelBotoes.add(Box.createRigidArea(new Dimension(0, 15)));

            btn.addActionListener(e -> {
                switch (opcao) {
                    case "Clientes": // abre tela clientes
                        abrirTela(new TelaClientes());
                        break;
                    case "Pacotes": // abre tela pacotes
                        abrirTela(new TelaPacotes());
                        break;
                    case "Serviços": // abre tela de serviços
                        abrirTela(new TelaServicos());
                        break;
                    case "Reservas": // abre tela das reservass
                        abrirTela(new TelaReservas());
                        break;
                    case "Sair": // ao clicar no botao sair, o sistema fecha
                        System.exit(0);
                        break;
                }
            });
        }

        contentPane.add(panelBotoes, BorderLayout.CENTER);
    }

    private JButton criarBotao(String texto) { 
        JButton btn = new JButton(texto);
        btn.setFont(new Font("Arial", Font.PLAIN, 16));
        btn.setForeground(Color.BLACK);
        btn.setBackground(Color.WHITE);
        btn.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setMaximumSize(new Dimension(250, 40));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(new Color(240, 240, 240)); 
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(Color.WHITE);
            }
        });
        
        return btn;
    }

    private void abrirTela(JFrame tela) {
        if (tela != null) {
            tela.setVisible(true);
            this.dispose(); 
        } else {
            JOptionPane.showMessageDialog(this, "Tela não implementada", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }
}