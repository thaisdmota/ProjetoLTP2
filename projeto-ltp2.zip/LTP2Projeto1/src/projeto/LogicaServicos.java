package projeto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class LogicaServicos {
    private DefaultTableModel modeloTabela;

    public LogicaServicos(DefaultTableModel modeloTabela) {
        this.modeloTabela = modeloTabela;
    }

    public void carregarTabelaServicos() {
        modeloTabela.setRowCount(0);
        String sql = "SELECT id, nome, preco FROM servicos_adicionais";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                modeloTabela.addRow(new Object[]{
                    rs.getInt("id"), 
                    rs.getString("nome"), 
                    rs.getDouble("preco")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, 
                "Erro ao carregar serviços: " + e.getMessage(), 
                "Erro", 
                JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean adicionarServico(String nome, String precoStr) {
        try {
            double preco = Double.parseDouble(precoStr);
            if (nome.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, 
                    "O nome do serviço é obrigatório.", 
                    "Erro", 
                    JOptionPane.WARNING_MESSAGE);
                return false;
            }
            if (!nome.matches("^[\\p{L} ]+$")) {  
            	JOptionPane.showMessageDialog(null, "Nome deve conter apenas letras.", "Erro", JOptionPane.WARNING_MESSAGE);
            	return false;
            }

            String sql = "INSERT INTO servicos_adicionais (nome, preco) VALUES (?, ?)";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, nome);
                stmt.setDouble(2, preco);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(null, 
                    "Serviço adicionado com sucesso!", 
                    "Sucesso", 
                    JOptionPane.INFORMATION_MESSAGE);
                carregarTabelaServicos();
                return true;
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, 
                    "Erro ao salvar serviço: " + e.getMessage(), 
                    "Erro", 
                    JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, 
                "O preço deve ser um número válido.", 
                "Erro de Formato", 
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public boolean excluirServico(int linhaSelecionada) {
        if (linhaSelecionada == -1) {
            JOptionPane.showMessageDialog(null, 
                "Selecione um serviço na tabela para excluir.", 
                "Aviso", 
                JOptionPane.WARNING_MESSAGE);
            return false;
        }

        int idServico = (int) modeloTabela.getValueAt(linhaSelecionada, 0);
        int confirmacao = JOptionPane.showConfirmDialog(null, 
            "Tem certeza que deseja excluir este serviço?", 
            "Confirmação", 
            JOptionPane.YES_NO_OPTION);
        if (confirmacao != JOptionPane.YES_OPTION) return false;

        try (Connection conn = DatabaseConnection.getConnection()) {

            String sqlCheck = "SELECT COUNT(*) FROM reserva_servicos WHERE servico_id = ?";
            try (PreparedStatement stmtCheck = conn.prepareStatement(sqlCheck)) {
                stmtCheck.setInt(1, idServico);
                ResultSet rs = stmtCheck.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(null, 
                        "Este serviço está vinculado a uma reserva e não pode ser excluído.", 
                        "Erro", 
                        JOptionPane.ERROR_MESSAGE);
                    return false;
                }
            }

            String sqlDelete = "DELETE FROM servicos_adicionais WHERE id = ?";
            try (PreparedStatement stmtDelete = conn.prepareStatement(sqlDelete)) {
                stmtDelete.setInt(1, idServico);
                stmtDelete.executeUpdate();
                JOptionPane.showMessageDialog(null, 
                    "Serviço excluído com sucesso!", 
                    "Sucesso", 
                    JOptionPane.INFORMATION_MESSAGE);
                carregarTabelaServicos();
                return true;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, 
                "Erro ao excluir serviço: " + e.getMessage(), 
                "Erro", 
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    public void buscarServico(String termoBusca) {
        modeloTabela.setRowCount(0);
        String sql = "SELECT id, nome, preco FROM servicos_adicionais WHERE nome LIKE ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, "%" + termoBusca + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    modeloTabela.addRow(new Object[]{
                        rs.getInt("id"), 
                        rs.getString("nome"), 
                        rs.getDouble("preco")
                    });
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, 
                "Erro ao buscar serviços: " + e.getMessage(), 
                "Erro", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
}