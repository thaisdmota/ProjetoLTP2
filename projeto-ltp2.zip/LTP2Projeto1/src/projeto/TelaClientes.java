package projeto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class TelaClientes extends JFrame {

    static JTextField txtNome;
	private JTextField txtTelefone;
	static JTextField txtEmail;
	private JTextField txtCpf;
	private JTextField txtPassaporte;
    private JRadioButton rbNacional, rbEstrangeiro;
    private ButtonGroup grupoTipoCliente;
    private JButton btnCadastrar, btnExcluir, btnLimpar;
    public static JTable tabelaClientes;
    static DefaultTableModel modeloTabela;
    private JLabel lblCpf, lblPassaporte;
    private JButton btnNewButton;
    private JButton btnNewButton_1;
    private JButton btnNewButton_2;

    public TelaClientes() {
        setTitle("Gerenciamento de Clientes");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout(10, 10));

        JPanel painelFormulario = new JPanel(new GridBagLayout());
        painelFormulario.setBorder(BorderFactory.createTitledBorder("Dados do Cliente"));
        
        GridBagConstraints gbcTipoLabel = new GridBagConstraints();
        gbcTipoLabel.gridx = 2;
        gbcTipoLabel.gridy = 0;
        gbcTipoLabel.insets = new Insets(5, 5, 5, 5);
        gbcTipoLabel.anchor = GridBagConstraints.WEST;
        painelFormulario.add(new JLabel("Tipo:"), gbcTipoLabel); // jlabel para parte do tipo de cliente, nac ou est

        rbNacional = new JRadioButton("Nacional", true); // botei nacional como seleção default
        rbEstrangeiro = new JRadioButton("Estrangeiro");
        grupoTipoCliente = new ButtonGroup();
        grupoTipoCliente.add(rbNacional);
        grupoTipoCliente.add(rbEstrangeiro);

        JPanel painelTipo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        painelTipo.add(rbNacional);
        painelTipo.add(rbEstrangeiro);

        GridBagConstraints gbcTipoPanel = new GridBagConstraints();
        gbcTipoPanel.gridx = 3;
        gbcTipoPanel.gridy = 0;
        gbcTipoPanel.gridwidth = 2;
        gbcTipoPanel.insets = new Insets(5, 5, 5, 5);
        gbcTipoPanel.fill = GridBagConstraints.HORIZONTAL;
        painelFormulario.add(painelTipo, gbcTipoPanel);

        GridBagConstraints gbcNomeLabel = new GridBagConstraints();
        gbcNomeLabel.gridx = 2;
        gbcNomeLabel.gridy = 1;
        gbcNomeLabel.insets = new Insets(5, 5, 5, 5);
       painelFormulario.add(new JLabel("Nome:"), gbcNomeLabel); //jlabel p mostrar onde o usuário deve informar o nome do cliente

        txtNome = new JTextField(20);
        GridBagConstraints gbcNomeField = new GridBagConstraints();
        gbcNomeField.gridx = 3;
        gbcNomeField.gridy = 1;
        gbcNomeField.gridwidth = 2;
        gbcNomeField.insets = new Insets(5, 5, 5, 5);
        gbcNomeField.fill = GridBagConstraints.HORIZONTAL;
        painelFormulario.add(txtNome, gbcNomeField);

        GridBagConstraints gbcEmailLabel = new GridBagConstraints();
        gbcEmailLabel.gridx = 2;
        gbcEmailLabel.gridy = 2;
        gbcEmailLabel.insets = new Insets(5, 5, 5, 5);
        painelFormulario.add(new JLabel("Email:"), gbcEmailLabel); //jlabel p mostrar onde o usuário deve informar o email do cliente

        txtEmail = new JTextField(20);
        GridBagConstraints gbcEmailField = new GridBagConstraints();
        gbcEmailField.gridx = 3;
        gbcEmailField.gridy = 2;
        gbcEmailField.gridwidth = 2;
        gbcEmailField.insets = new Insets(5, 5, 5, 5);
        gbcEmailField.fill = GridBagConstraints.HORIZONTAL;
        painelFormulario.add(txtEmail, gbcEmailField);

        GridBagConstraints gbcTelefoneLabel = new GridBagConstraints();
        gbcTelefoneLabel.gridx = 2;
        gbcTelefoneLabel.gridy = 3;
        gbcTelefoneLabel.insets = new Insets(5, 5, 5, 5);
        painelFormulario.add(new JLabel("Telefone:"), gbcTelefoneLabel); //jlabel p mostrar onde o usuário deve informar o telefone do cliente

        txtTelefone = new JTextField(20);
        GridBagConstraints gbcTelefoneField = new GridBagConstraints();
        gbcTelefoneField.gridx = 3;
        gbcTelefoneField.gridy = 3;
        gbcTelefoneField.gridwidth = 2;
        gbcTelefoneField.insets = new Insets(5, 5, 5, 5);
        gbcTelefoneField.fill = GridBagConstraints.HORIZONTAL;
        painelFormulario.add(txtTelefone, gbcTelefoneField);

        lblCpf = new JLabel("CPF:"); //jlabel p mostrar onde o usuário deve informar o cpf do cliente
        GridBagConstraints gbcCpfLabel = new GridBagConstraints();
        gbcCpfLabel.gridx = 2;
        gbcCpfLabel.gridy = 4;
        gbcCpfLabel.insets = new Insets(5, 5, 5, 5);
        painelFormulario.add(lblCpf, gbcCpfLabel); 

        txtCpf = new JTextField(20);
        GridBagConstraints gbcCpfField = new GridBagConstraints();
        gbcCpfField.gridx = 3;
        gbcCpfField.gridy = 4;
        gbcCpfField.gridwidth = 2;
        gbcCpfField.insets = new Insets(5, 5, 5, 5);
        gbcCpfField.fill = GridBagConstraints.HORIZONTAL;
        painelFormulario.add(txtCpf, gbcCpfField);

        lblPassaporte = new JLabel("Passaporte:"); //jlabel p mostrar onde o usuário deve informar o passaporte do cliente
        GridBagConstraints gbcPassaporteLabel = new GridBagConstraints();
        gbcPassaporteLabel.gridx = 2;
        gbcPassaporteLabel.gridy = 5;
        gbcPassaporteLabel.insets = new Insets(5, 5, 5, 5);
        painelFormulario.add(lblPassaporte, gbcPassaporteLabel);

        txtPassaporte = new JTextField(20);
        GridBagConstraints gbcPassaporteField = new GridBagConstraints();
        gbcPassaporteField.gridx = 3;
        gbcPassaporteField.gridy = 5;
        gbcPassaporteField.gridwidth = 2;
        gbcPassaporteField.insets = new Insets(5, 5, 5, 5);
        gbcPassaporteField.fill = GridBagConstraints.HORIZONTAL;
        painelFormulario.add(txtPassaporte, gbcPassaporteField);

        modeloTabela = new DefaultTableModel(new Object[]{"ID", "Nome", "Email", "Telefone", "Tipo", "Documento"}, 0); // aqui é onde vai ficar o carregamento de info de clientes
        tabelaClientes = new JTable(modeloTabela);
        tabelaClientes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(tabelaClientes);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Clientes Cadastrados"));
        getContentPane().add(painelFormulario, BorderLayout.NORTH);
                
                btnNewButton_2 = new JButton("Buscar pacotes contratados"); // botão p busca
                btnNewButton_2.addActionListener(new ActionListener() {
                	public void actionPerformed(ActionEvent e) {
                		LogicaCliente.visualizarPacotesCliente();
                	}
                });
                GridBagConstraints gbc_btnNewButton_2 = new GridBagConstraints();
                gbc_btnNewButton_2.insets = new Insets(0, 0, 0, 5);
                gbc_btnNewButton_2.gridx = 0;
                gbc_btnNewButton_2.gridy = 6;
                painelFormulario.add(btnNewButton_2, gbc_btnNewButton_2);
        

                JPanel painelBotoesForm = new JPanel(new FlowLayout(FlowLayout.CENTER));
                btnCadastrar = new JButton("Cadastrar"); // botão p confirmar cadastro 
                
                btnLimpar = new JButton("Limpar Campos"); // botão p limpar campo caso o usuário/funcionario volte atrás
                
                painelBotoesForm.add(btnCadastrar);
                painelBotoesForm.add(btnLimpar);
                
                GridBagConstraints gbc = new GridBagConstraints();
                gbc.insets = new Insets(0, 0, 0, 5);
                gbc.gridx = 1; 
                gbc.gridy = 6; 
                gbc.gridwidth = 3;
                painelFormulario.add(painelBotoesForm, gbc);
                
                btnNewButton = new JButton("Buscar Cliente");
                btnNewButton.addActionListener(new ActionListener() { // aq chama a lógica p buscar cliente no banco de dados
                	public void actionPerformed(ActionEvent e) {
                		LogicaCliente.buscarCliente();
                	}
                });
                
                GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
                gbc_btnNewButton.insets = new Insets(0, 0, 0, 5);
                gbc_btnNewButton.gridx = 4;
                gbc_btnNewButton.gridy = 6;
                painelFormulario.add(btnNewButton, gbc_btnNewButton);
                
                btnLimpar.addActionListener(e ->  // aq chama a lógica p limpar os campos q tinham sido inseridos
                LogicaCliente.limparCampos(txtNome, txtEmail, txtTelefone, txtCpf, txtPassaporte, 
                                             rbNacional));

                btnCadastrar.addActionListener(e -> { //aq chama a lógica de cadastro de clientes
                    try {
                        String nome = txtNome.getText().trim();
                        String email = txtEmail.getText().trim();
                        String telefone = txtTelefone.getText().trim();
                        String cpf = txtCpf.getText().trim();
                        String passaporte = txtPassaporte.getText().trim();
                        String tipoCliente = rbNacional.isSelected() ? "Nacional" : "Estrangeiro";
                        String documento = tipoCliente.equals("Nacional") ? cpf : passaporte;
                        LogicaCliente.validarDadosCliente(nome, documento, telefone, email, tipoCliente);
                        LogicaCliente.cadastrarCliente(
                            this,
                            txtNome,
                            txtEmail,
                            txtTelefone,
                            txtCpf,
                            txtPassaporte,
                            rbNacional,
                            modeloTabela
                        );

                    } catch (IllegalArgumentException ex) {
                        JOptionPane.showMessageDialog(this, "Erro ao cadastrar cliente: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, "Erro inesperado: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                });

        getContentPane().add(scrollPane, BorderLayout.CENTER);
        JPanel painelAcoesTabela = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnExcluir = new JButton("Excluir Cliente Selecionado"); // botao p excluir cliente
        btnExcluir.addActionListener(e -> {
            LogicaCliente.excluirCliente(this, tabelaClientes, modeloTabela); // chama o método de excluir cliente, que está na classe LogicaCliente
            carregarTabelaClientes(); 
        });
        painelAcoesTabela.add(btnExcluir);  
        
        getContentPane().add(painelAcoesTabela, BorderLayout.SOUTH);
        btnNewButton_1 = new JButton("Voltar ao Menu Principal"); // botão p voltar ao menu (TelaPrincipal)
        btnNewButton_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		TelaPrincipal TelaPrincipal = new TelaPrincipal();
        		TelaPrincipal.setVisible(true);
        		TelaClientes.this.dispose();
        	}
        });
        
        painelAcoesTabela.add(btnNewButton_1);
        ActionListener listenerTipoCliente = e -> atualizarVisibilidadeDocumento();
        rbNacional.addActionListener(listenerTipoCliente);
        rbEstrangeiro.addActionListener(listenerTipoCliente);
        carregarTabelaClientes();
        atualizarVisibilidadeDocumento(); 
        
    }

    private void atualizarVisibilidadeDocumento() {
        boolean isNacional = rbNacional.isSelected();
        lblCpf.setVisible(isNacional);
        txtCpf.setVisible(isNacional);
        lblPassaporte.setVisible(!isNacional);
        txtPassaporte.setVisible(!isNacional);
    }

    public static void carregarTabelaClientes() { // método para carregar as info dos clientes
        modeloTabela.setRowCount(0);
        String sql = "SELECT id, nome, email, telefone, tipo, cpf, passaporte FROM clientes ORDER BY nome";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String tipo = rs.getString("tipo");
                String documento = "NACIONAL".equalsIgnoreCase(tipo) ? rs.getString("cpf") : rs.getString("passaporte");
                
                modeloTabela.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("email"),
                    rs.getString("telefone"),
                    tipo,
                    documento
                });
            }
        } catch (SQLException e) {
        	JOptionPane.showMessageDialog(null, "Erro ao carregar clientes: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TelaClientes tela = new TelaClientes();
            tela.setVisible(true);
        });
    
    }
}