package projeto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaServicos extends JFrame {

    private JTextField txtNome;
    private JTextField txtBusca;
    private JTextField txtPreco;
    private JButton btnAdicionar;
    private JButton btnLimpar;
    private JButton btnExcluir;
    private JTable tabelaServicos;
    private DefaultTableModel modeloTabela;
    private LogicaServicos logicaServicos;
    private JButton btnNewButton;
    private JButton btnNewButton_1;

    public TelaServicos() {
        setTitle("Gerenciamento de Serviços Adicionais");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout(10, 10));

        modeloTabela = new DefaultTableModel(new Object[]{"ID", "Nome", "Preço"}, 0);
        logicaServicos = new LogicaServicos(modeloTabela);

        JPanel painelFormulario = new JPanel(new GridBagLayout());
        painelFormulario.setBorder(BorderFactory.createTitledBorder("Adicionar Novo Serviço"));

        GridBagConstraints gbcNomeLabel = new GridBagConstraints();
        gbcNomeLabel.gridx = 1;
        gbcNomeLabel.gridy = 0;
        gbcNomeLabel.insets = new Insets(5, 5, 5, 5);
        gbcNomeLabel.anchor = GridBagConstraints.LINE_END;
        
        painelFormulario.add(new JLabel("Nome:"), gbcNomeLabel);
        JPanel painelBusca = new JPanel(new FlowLayout(FlowLayout.LEFT));
        painelBusca.add(new JLabel("Buscar serviço:"));
        txtBusca = new JTextField(20);
        painelBusca.add(txtBusca);
        btnNewButton_1 = new JButton("Buscar");
        painelBusca.add(btnNewButton_1);
        GridBagConstraints gbcBusca = new GridBagConstraints();
        gbcBusca.gridx = 1;
        gbcBusca.gridy = 3;
        gbcBusca.gridwidth = 2;
        gbcBusca.insets = new Insets(5, 5, 5, 5);
        gbcBusca.fill = GridBagConstraints.HORIZONTAL;
        painelFormulario.add(painelBusca, gbcBusca);

        GridBagConstraints gbcNomeCampo = new GridBagConstraints();
        gbcNomeCampo.gridx = 2;
        gbcNomeCampo.gridy = 0;
        gbcNomeCampo.insets = new Insets(5, 5, 5, 5);
        gbcNomeCampo.fill = GridBagConstraints.HORIZONTAL;
        txtNome = new JTextField(20);
        painelFormulario.add(txtNome, gbcNomeCampo);

        GridBagConstraints gbcPrecoLabel = new GridBagConstraints();
        gbcPrecoLabel.gridx = 1;
        gbcPrecoLabel.gridy = 1;
        gbcPrecoLabel.insets = new Insets(5, 5, 5, 5);
        gbcPrecoLabel.anchor = GridBagConstraints.LINE_END;
        painelFormulario.add(new JLabel("Preço (R$):"), gbcPrecoLabel);

        GridBagConstraints gbcPrecoCampo = new GridBagConstraints();
        gbcPrecoCampo.gridx = 2;
        gbcPrecoCampo.gridy = 1;
        gbcPrecoCampo.insets = new Insets(5, 5, 5, 5);
        gbcPrecoCampo.fill = GridBagConstraints.HORIZONTAL;
        txtPreco = new JTextField(10);
        painelFormulario.add(txtPreco, gbcPrecoCampo);

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnAdicionar = new JButton("Adicionar");
        btnLimpar = new JButton("Limpar");
        painelBotoes.add(btnAdicionar);
        painelBotoes.add(btnLimpar);

        GridBagConstraints gbcBotoes = new GridBagConstraints();
        gbcBotoes.gridx = 1;
        gbcBotoes.gridy = 2;
        gbcBotoes.gridwidth = 2;
        gbcBotoes.insets = new Insets(10, 5, 0, 5);
        painelFormulario.add(painelBotoes, gbcBotoes);

        tabelaServicos = new JTable(modeloTabela);
        JScrollPane scrollTabela = new JScrollPane(tabelaServicos);
        scrollTabela.setBorder(BorderFactory.createTitledBorder("Serviços Disponíveis"));

        JPanel painelExcluir = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnExcluir = new JButton("Excluir Serviço Selecionado");
        painelExcluir.add(btnExcluir);
        
        btnNewButton = new JButton("Voltar ao Menu Principal");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                TelaPrincipal TelaPrincipal = new TelaPrincipal();
                TelaPrincipal.setVisible(true);
                TelaServicos.this.dispose();
            }
        });
        painelExcluir.add(btnNewButton);

        getContentPane().add(painelFormulario, BorderLayout.NORTH);
        getContentPane().add(scrollTabela, BorderLayout.CENTER);
        getContentPane().add(painelExcluir, BorderLayout.SOUTH);

        btnAdicionar.addActionListener(e -> adicionarServico());
        btnLimpar.addActionListener(e -> limparCampos());
        btnExcluir.addActionListener(e -> excluirServico());
        btnNewButton_1.addActionListener(e -> buscarServico());
        txtBusca.addActionListener(e -> buscarServico());
        carregarTabelaServicos();
    }
    
    private void buscarServico() {
        String termoBusca = txtBusca.getText().trim();
        if (termoBusca.isEmpty()) {
            carregarTabelaServicos();
            JOptionPane.showMessageDialog(this, 
                "Digite um termo para buscar", 
                "Aviso", 
                JOptionPane.INFORMATION_MESSAGE);
        } else {
            logicaServicos.buscarServico(termoBusca);
            if (modeloTabela.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, 
                    "Nenhum serviço encontrado com o termo: " + termoBusca, 
                    "Resultado da Busca", 
                    JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    private void carregarTabelaServicos() {
        logicaServicos.carregarTabelaServicos();
    }

    private void adicionarServico() {
        boolean sucesso = logicaServicos.adicionarServico(
            txtNome.getText(), 
            txtPreco.getText()
        );
        if (sucesso) {
            limparCampos();
        }
    }

    private void excluirServico() {
        logicaServicos.excluirServico(tabelaServicos.getSelectedRow());
    }

    private void limparCampos() {
        txtNome.setText("");
        txtPreco.setText("");
        tabelaServicos.clearSelection();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TelaServicos tela = new TelaServicos();
            tela.setVisible(true);
        });
    }
}